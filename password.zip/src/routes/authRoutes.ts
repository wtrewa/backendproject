
import { Request, Response, Router } from "express";
import { login, registerUser } from "../controllers/authController";

const authRoute = Router();

authRoute.post("/signup", registerUser);
authRoute.post("/login", login);

export default authRoute;
