import { Router } from "express";
import {  getPasswords, savePassword } from "../controllers/passwordController";
import { authenticateToken } from "../middleware/authMiddleware";


const passwordRoute = Router();

// Route to save a password
passwordRoute.post("/password",authenticateToken, savePassword);
passwordRoute.get("/passwords",authenticateToken, getPasswords);

export default passwordRoute;
