import { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import validator from "validator";
import nodemailer from "nodemailer";
import { createCustomError } from "../helpers/errorHandler";


interface SendVerificationCodeRequestBody {
  email: string;
}

export const sendVerificationCode = async (
  req: Request<{}, {}, SendVerificationCodeRequestBody>,
  res: Response,
  next: NextFunction
): Promise<void> => {
  const { email } = req.body;
  console.log(email)

  // Check if email is provided
  if (!email) {
    return next(createCustomError(400, "Email is required"));
  }

  // Generate a random 6-digit verification code
  const verificationCode = crypto.randomInt(100000, 999999).toString();

  try {
    // Validate email format
    if (!validator.isEmail(email)) {
      return next(createCustomError(400, "Invalid email format"));
    }

    // Create transporter object using Gmail service
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_PASS,
      },
    });

    // Email message options
    const mailOptions: nodemailer.SendMailOptions = {
      from: process.env.GMAIL_USER,
      to: email,
      subject: "Email Verification",
      text: `Your verification code is: ${verificationCode}`,
    };

    // Send email using transporter
    await transporter.sendMail(mailOptions);

    // Respond with success message and verification code
    res
      .status(200)
      .json({ message: "Verification code sent", code: verificationCode });
  } catch (error) {
    console.error("Error sending verification code:", error);
    next(createCustomError(500, "Failed to send verification email"));
  }
};
