const crypto = require('crypto');

// Define the algorithm and key
const algorithm = 'aes-256-cbc';
const key = crypto.randomBytes(32); // Generate a random key
const iv = crypto.randomBytes(16); // Initialization vector

/**
 * Encrypts the given password.
 * @param {string} password - The password to encrypt.
 * @returns {string} - The encrypted password in hexadecimal format.
 */
export function encrypt(password) {
    const cipher = crypto.createCipheriv(algorithm, key, iv);
    let encrypted = cipher.update(password, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}

/**
 * Decrypts the given encrypted password.
 * @param {string} encryptedPassword - The password to decrypt.
 * @returns {string} - The decrypted password.
 */
export function decrypt(encryptedPassword) {
    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    let decrypted = decipher.update(encryptedPassword, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}


