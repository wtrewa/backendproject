import { DataTypes, Model, Optional } from "sequelize";
import sequelize from "../config/connection"; // Adjust the path as needed

interface PasswordAttributes {
  id: number;
  url: string;
  password: string;
  userId?: number; // Make userId optional if it's not required
}

interface PasswordCreationAttributes
  extends Optional<PasswordAttributes, "id"> {}

class Password
  extends Model<PasswordAttributes, PasswordCreationAttributes>
  implements PasswordAttributes
{
  public id!: number;
  public url!: string;
  public password!: string;
  public userId?: number;
}

Password.init(
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    url: {
      type:DataTypes.STRING(1000),
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: "users", // Use the table name instead of the model reference
        key: "id",
      },
      onUpdate: "CASCADE",
      onDelete: "SET NULL",
    },
  },
  {
    sequelize,
    modelName: "Password",
  }
);

export default Password;