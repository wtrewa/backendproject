import express from "express";
import passport from "passport";
import { googleAuth, googleCallback } from "../controllers/googleAuthController";

const googleAuthRoute = express.Router();


// Route to start the OAuth 2.0 flow
googleAuthRoute.get("/google", googleAuth);

// OAuth 2.0 callback route
googleAuthRoute.get("/google/callback", googleCallback);




export default googleAuthRoute;

