import { Request, Response } from "express";
import { hash } from "bcrypt";
 // Ensure the correct path
import User from "../models/User"; // Ensure the correct path
import Password from '../models/password';
import { encrypt } from "../utils/crypto";
import { decrypt } from "dotenv";


export const savePassword = async (req: Request, res: Response) => {
  const { url, password } = req.body;
  const userId = 1; // Replace with actual user ID retrieval logic

  if (!url || !password) {
    return res.status(400).json({ message: "All fields are required" });
  }

  try {
    // Encrypt the password
    const encryptedPassword = encrypt(password);
    console.log(encryptedPassword)
    // Save the password
    const newPassword = await Password.create({
      url,
      password: encryptedPassword,
      userId,
    });

    res.status(201).json(newPassword);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};



export const getPasswords = async (req: Request, res: Response) => {
  const userId:number =  req.user?.id

  try {
    const passwords = await Password.findAll({
      where: { userId },
    });

    // Decrypt the passwords before sending
    const decryptedPasswords = passwords.map(password => ({
      ...password.toJSON(),
      password: decrypt(password.password),
    }));

    res.status(200).json(decryptedPasswords);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal server error" });
  }
};